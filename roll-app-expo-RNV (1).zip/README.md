
# Roll App (Expo)

## Запуск
```bash
npm install
npx expo start
```

## Сборка APK (EAS)
```bash
npm i -g eas-cli
eas build:configure
eas build -p android --profile preview
```

## Публикация в Google Play (AAB)
```bash
eas build -p android --profile production
eas submit -p android --profile production
```
